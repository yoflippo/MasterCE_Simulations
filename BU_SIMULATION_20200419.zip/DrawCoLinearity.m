xc = [-1 1 1]; yc = [20 -7 10]; r = [20 15 15];
DrawTrilaterionCircles(xc,yc,r,'CoLinearity_trilaterion')