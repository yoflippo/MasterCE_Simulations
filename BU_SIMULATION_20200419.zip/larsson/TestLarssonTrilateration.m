%% Test Larsson
close all;
clearvars; clc; mfilename('fullpath')
curPath = fileparts(mfilename('fullpath'));
addpath(genpath(curPath));
cd(curPath);
cd ..

% Find .mat files with dummy data
matfiles = dir('*.mat');
matfiles(~contains({matfiles.name},'uwb'))=[];
load(matfiles(1).name);

% Give number of dummy data files you want to use
numberOfPlotsToOpen = 30;
if numberOfPlotsToOpen >  length(matfiles)
    numberOfPlotsToOpen = length(matfiles);
end

% Create noise matrices, so noise is the same for the same number of
% ANCHORS
noise = createNoiseForMatrices(length(data.TagPositions),true);

%% Compare
for i = 1:numberOfPlotsToOpen
    fn = matfiles(i).name;
    load(fn);
    %% Clean
    res.clean = executeLarssonTrilateration(data);
    plotLarsson(fn,res.clean)
    title('Clean data');
    
    %% With noise
    % % %     [r,c] = size(data.Distances);
    % % %     data.Distances = data.Distances + noise{c}; % times 6 gives approx. 20 cm of variation
    
    % UWB noise due to larger distance
    data.Distances = createUWBNoise(data.Distances,5);
    
    res.noise = executeLarssonTrilateration(data);
    plot(res.noise(:,1),res.noise(:,2),'rx','MarkerSize',5,'LineWidth',2);
    title(['Error_{clean} is ' getCalculatedErrorString(data.TagPositions,res.clean) ...
        '                   Error_{noise} is ' getCalculatedErrorString(data.TagPositions,res.noise)],'Interpreter','tex');
    clear r
end

% Order the plots
distFig('Tight',true)


%% ==================================== FUNCTIONS ====================================
function [result] = executeLarssonTrilateration(data)
for i = 1:length(data.Distances())
    result(i,1:2) = solver_opttrilat(data.AnchorPositions',data.Distances(i,:))';
end
end


function plotLarsson(fn,result)
warning off
open([replace(fn,'.mat','') '.fig'])
hold on;
plot(result(:,1),result(:,2),'gx','MarkerSize',5,'LineWidth',2);
end


function error = getCalculatedErrorString(clean,dirty)
error = num2str(round(sum(dis(clean,dirty))));
end


function d = dis(pos1,pos2)
d = sqrt((pos2(:,1)-pos1(:,1)).^2+(pos2(:,2)-pos1(:,2)).^2);
end


function noise = createNoiseForMatrices(r,blDistNormal)
maxNumberOfExpectedColumns = 15;
range = 20; % cm
normalFactor = range/3;
for nC = 1:maxNumberOfExpectedColumns
    if blDistNormal
        % normally distributed
        noise{nC} = normalFactor*randn(r,nC); 
    else
        % uniformly distributed
        noise{nC} = -range + (2*range)*rand(r,nC);
    end
end
end


function distanceWithNoise = createUWBNoise(distances,percentage)
%% Work in Progress
if percentage > 1
    percentage = percentage / 100;
end

% More distance means more noise
[r,c] = size(distances);
distanceWithNoise = zeros(r,c);
for nR = 1:r
    for nC = 1:c
        currentDistance = distances(nR,nC);
%         
%         % uniformly
%         range = percentage * currentDistance;
%         noise = -range + (2*range)*rand(1,1);
%         distanceWithNoise(nR,nC) = currentDistance +  noise;
        
        % normally distributed
        normalFactor = (currentDistance*percentage)/3;
        noise = normalFactor*randn(1,1); 
        distanceWithNoise(nR,nC) = currentDistance +  noise;
    end
end
end
