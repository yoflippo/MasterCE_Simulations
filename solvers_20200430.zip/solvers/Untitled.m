close all;
clearvars;
clc

A = [3 3; -1 -1]';

% Create rotation matrix
theta = 350; 
R = [cosd(theta) -sind(theta); sind(theta) cosd(theta)];
% Rotate your point(s)
point = A; % arbitrarily selected
rotpoint = R*point;

plot(A(1,:),A(2,:),'go');
hold on; 
plot(rotpoint(1,:),rotpoint(2,:),'rx')