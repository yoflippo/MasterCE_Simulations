
function error = getErrorLocations(clean,dirty)
error = round(sum(dis(clean,dirty))); 
%% (distance - measured distance )^2
end
