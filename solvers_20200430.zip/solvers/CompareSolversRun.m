close all;
clearvars;
clc;

mfilename('fullpath')
curPath = fileparts(mfilename('fullpath'));
rmpath(genpath(curPath));
addpath(genpath(curPath));
cd(curPath);

warning on
% results = CompareSolvers(@executeLarssonTrilateration, 'Larsson',@executeFabertMultiLateration2,'Faber2',true);
results = CompareSolvers(@executeLarssonTrilateration,'Larsson',@executeFabertMultiLateration2a,'Faber2a',true);
% results = CompareSolvers(@executeLarssonTrilateration,'Larsson',@executeFabertMultiLateration2b,'Faber2b',true);
% results = CompareSolvers(@executeLarssonTrilateration,'Larsson',@executeFabertMultiLateration9,'Faber9',true);

figure
bar([results.error.DiffDisSqr1; results.error.DiffDisSqr2]');
legend(results.name1,results.name2,'Location','best')
title(['Sum error ' results.name1 ': ' num2str(round(sum(results.error.DiffDisSqr1),1)) ', ' ...
    'Sum error ' results.name2 ': ' num2str(round(sum(results.error.DiffDisSqr2),1))]);
ylabel('Error')
xlabel('Different Anchor set ups');

% figure
% bar([results.duration.noise1; results.duration.noise2]');
% legend(results.name1,results.name2,'Location','best')
% title(['Duration ' results.name1 ': ' num2str(sum(results.duration.noise1)) ', ' ...
%     'Duration ' results.name2 ': ' num2str(sum(results.duration.noise2))]);
% ylabel('Duration')
% xlabel('Different Anchor set ups');
%% process results

