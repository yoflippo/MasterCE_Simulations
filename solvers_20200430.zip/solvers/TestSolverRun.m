close all;
clearvars;
clc;

TestSolver(@executeLarssonTrilateration, 'Larsson');
% TestSolver(@executeFabertMultiLateration, 'Faber');
% TestSolver(@executeFabertMultiLateration2, 'Faber2');

