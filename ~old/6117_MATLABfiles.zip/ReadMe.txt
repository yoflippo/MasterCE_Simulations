====================================================================
============================ CHAPTER-2 =============================
====================================================================
UWB Pulse Generation:

GausDoublet.m     : Generates Gaussian doublets.

modifiedHermite.m : Generates UWB pulses based on modified Hermite polynomials

Gaus5thDer.m	  : Generates the 5th derivative of the Gaussian pulse


Problem Solution:

chap2prob4.m	  : A MATLAB script for the solution of Problem 4 in Chapter 2
====================================================================
====================================================================



====================================================================
============================ CHAPTER-3 =============================
====================================================================
Problem Solution:

chap3prob6.m	: A MATLAB script for the solution of Problem 6 in Chapter 3
====================================================================
====================================================================



====================================================================
============================ CHAPTER-4 =============================
====================================================================
Effective bandwidth:

effBW.m     : Calculates the effective bandwidth of the Gaussian doublet (i.e., the second derivative of the Gaussian pulse)


CRLB versus SNR:

CRLBvsSNR.m : A MATLAB script that plots the CRLBs on the unbiased TOA estimators for the Gaussian doublet



Problem Solution:

chap4prob8.m	  : A MATLAB script for the solution of Problem 8 in Chapter 4
====================================================================
====================================================================



====================================================================
============================ CHAPTER-5 =============================
====================================================================
Channel Parameters:

calc_mean_excess_delay_spread.m : Calculates the mean excess delay spread for a certain channel impulse response

calc_rms_delay_spread.m 	: Calculates the rms delay spread for a certain channel impulse response


Q-Function:

Q_fn.m		  : Q-function


Pulses and Correlations:

pulses		  : Generates the first or the second derivative of the Gaussian pulse together with its derivative

pulseCorr	  : Calculates correlations of two pulses

autoCorr	  : Calculates autocorrelation of a pulse


Problem Solutions:

chap5prob235.m	  : A MATLAB script for the solutions of Problem 2,3,5 in Chapter 5

chap5prob7.m	  : A MATLAB script for the solution of Problem 7 in Chapter 5

chap5prob8.m	  : A MATLAB script for the solution of Problem 8 in Chapter 5
====================================================================
====================================================================



====================================================================
============================ CHAPTER-8 =============================
====================================================================
Link Budget Analysis: 

linkBudgetAnalysis.m : Calculates the SNRs based on link budget analysis (please refer to Example 8.3 and Problem 3 of Chapter-8)


Problem Solution:

chap8prob3.m	  : A MATLAB script for the solution of Problem 3 in Chapter 8
====================================================================
====================================================================
