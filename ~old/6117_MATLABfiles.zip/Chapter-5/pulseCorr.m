% Copyright �2008 
% Sinan Gezici

function [out] = pulseCorr(pulse1, pulse2, delay1, delay2, res)

if delay1>delay2
    delta = delay1-delay2;
    pulse1 = [zeros(1,delta) pulse1];
    pulse2 = [pulse2 zeros(1,delta)];
end

if delay1<=delay2
    delta = delay2-delay1;
    pulse2 = [zeros(1,delta) pulse2];
    pulse1 = [pulse1 zeros(1,delta)];
end

out = res * (pulse1 * pulse2') ;