
Channel Parameters:

calc_mean_excess_delay_spread.m : Calculates the mean excess delay spread for a certain channel impulse response

calc_rms_delay_spread.m 	: Calculates the rms delay spread for a certain channel impulse response


Q-Function:

Q_fn.m		  : Q-function


Pulses and Correlations:

pulses		  : Generates the first or the second derivative of the Gaussian pulse together with its derivative

pulseCorr	  : Calculates correlations of two pulses

autoCorr	  : Calculates autocorrelation of a pulse


Problem Solutions:

chap5prob235.m	  : A MATLAB script for the solutions of Problem 2,3,5 in Chapter 5

chap5prob7.m	  : A MATLAB script for the solution of Problem 7 in Chapter 5

chap5prob8.m	  : A MATLAB script for the solution of Problem 8 in Chapter 5