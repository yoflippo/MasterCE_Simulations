% Copyright �2008 
% Sinan Gezici

% Calculates the second derivative of the Gaussian pulse and its derivative
function [pulse, pulseDer] = pulses (option, zeta, ener, res)
% zeta  : Pulse parameter in seconds
% ener  : Energy of the pulse
% res   : Resolution 

%res = zeta/1e3 ;  % resolution
t = (-3*zeta):res:(3*zeta) ;

if option==1
    % First derivative of the Gaussian pulse and its derivative
    pulse = t .* exp(-2*pi*t.^2/zeta^2) ;
    pulseDer = exp(-2*pi*t.^2/zeta^2) .* (1-4*pi*t.^2/zeta^2) ;
end

if option==2
    % Second derivative of the Gaussian pulse and its derivative
    pulse = exp(-2*pi*t.^2/zeta^2) .* (1-4*pi*t.^2/zeta^2) ;
    pulseDer = exp(-2*pi*t.^2/zeta^2) .* (16*pi^2*t.^3/zeta^4-12*pi*t/zeta^2) ;
end

% Scale pulse energies
E1 = res * sum(pulse.^2); 
pulse = sqrt(ener) * pulse / sqrt(E1) ;
pulseDer = sqrt(ener) * pulseDer / sqrt(E1) ;

