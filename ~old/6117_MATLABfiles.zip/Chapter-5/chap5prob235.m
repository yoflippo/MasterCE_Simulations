% Copyright �2008 
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

% Chapter-5 Problems-2,3,5

% 5.2a)

alpha  = [0.5 2 -1.5 3 -2 1.5 1 -0.5 0.5 0.25 0.25];    % Channel impulse response
signal = 0.1*randn(1,200);                              % Noise with variance 0.01
signal(50:60) = signal(50:60)+alpha;                    % The TOA is at the 50th sample
figure, stem(signal), axis tight, grid on               % Plot the received signal samples
xlabel ('Sample index'), ylabel ('Amplitude')

% 5.2b)
xi    = [0.2 0.3 0.4];                                  % The three thresholds as given in in Problem 5.2b)
mu    = 0.5;                                            % Mean of the leading edge sample 
sigma = 0.1;                                            % Standard deviation of noise
P_d   = (1-2*Q_fn (xi/sigma)).^50 .* (Q_fn((xi-mu)/sigma) + Q_fn((xi+mu)/sigma))    
% Note that the detection of the leading edge occurs when the first 50
% samples prior to the leading edge sample are missed, and the leading edge
% sample itself is detected. 

% 5.3)

xi    = [0.2 0.3 0.4];                                  % The three thresholds as given in Problem 5.3)
mu    = [0.5 2 1.5];                                    % Mean of the three samples prior to the strongest sample
sigma = 0.1;                                            % Standard deviatino of noise
P_d   = (Q_fn((xi-mu(3))/sigma) + Q_fn((xi+mu(3))/sigma)) ...
    .*(Q_fn((xi-mu(2))/sigma) + Q_fn((xi+mu(2))/sigma)) ...
    .*(Q_fn((xi-mu(1))/sigma) + Q_fn((xi+mu(1))/sigma)) .* (1-2*Q_fn (xi/sigma))
% Note that the detection of the leading edge occurs when the three
% samples prior to the strongest sample are larger than the threshold, and
% the fourth sample prior to the leading edge is smaller than the threshold


% 5.5)

sigma = 0.1;                                            % Standard deviation of noise
res   = 0.01;                                           % Resolution of the increments for the integration variable
mu    = 0.1;                                            % Mean of the received signal sample
x     = 0:res:1e3;                                      % Integration variable (absolute values of the received signal samples)
pdf1  = 1/sqrt(2*pi*sigma^2) *  ( exp(-((x-mu).^2) / (2*sigma^2) )  +  exp(-((x+mu).^2) / (2*sigma^2) ) );  
% Note that above is the PDF of absolute value of a Gaussian disttribution with (mean,variance)=(mu,sigma^2)
q_var1= (1-2*Q_fn(x/sigma)).^199;                       % 
P_d   = sum ( pdf1 .* q_var1 * res )
% Probability of detection is calculated by integrating pdf1.* q_var1 over
% possible values of x. Basically for a given value of x, probability of
% the desired sample being larger than all the other 199 samples is
% calculated. 