function [y] = Q_fn(x)

y = 0.5*erfc(x/sqrt(2));