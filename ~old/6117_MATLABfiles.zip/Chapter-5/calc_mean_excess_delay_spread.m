% Copyright �2008 
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

function t_m = calc_mean_excess_delay_spread (h,t)
% Calculates the mean excess delay spread for a certain channel impulse response
% First removes any offset in front of the channel impulse response

% h          : Channel impulse vector
% t          : Time index for the samples in the channel impulse vector h

% Example:
% t       = transpose(1:10);
% h       = 2*exp(-t/2);
% h       = h/sum(abs(h.^2));
% t_m1    = calc_mean_excess_delay_spread (h,t);
% t_rms1  = calc_rms_delay_spread (h,t,t_m1);

tmp = find(h>0);
h = circshift(h,[0,tmp(1)-1]);              % remove any offest in front of CIR

t_m = sum ( t' .* abs(h).^2 ) / sum ( abs(h).^2 );