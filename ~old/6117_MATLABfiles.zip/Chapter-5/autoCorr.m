% Copyright �2008 
% Sinan Gezici

function [out] = autoCorr(pulse, delay, res)

pulse1 = [zeros(1,delay)  pulse];
pulse2 = [pulse  zeros(1,delay)];

out = res * (pulse1 * pulse2') ;