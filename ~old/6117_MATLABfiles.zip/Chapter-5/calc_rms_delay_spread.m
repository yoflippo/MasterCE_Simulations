% Copyright �2008 
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

function t_rms = calc_rms_delay_spread (h,t,t_m)
% Calculates the rms delay spread for a certain channel impulse response
% First removes any offset in front of the channel impulse response

% h          : Channel impulse vector
% t          : Time index for the samples in the channel impulse vector h
% t_m        : Mean excess delay of the channel vector h

% Example:
% t       = transpose(1:10);
% h       = 2*exp(-t/2);
% h       = h/sum(abs(h.^2));
% t_m1    = calc_mean_excess_delay_spread (h,t);
% t_rms1  = calc_rms_delay_spread (h,t,t_m1);

tmp = find(h>0);
h = circshift(h,[0,tmp(1)-1]);              % remove any offest in front of CIR

t_rms = sqrt( sum ( transpose((t-t_m).^2) .* abs(h).^2 ) / sum ( abs(h).^2 ) );