% Copyright �2008 
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

% Chapter-5 Problem-8

% Calculates ZZLB and CRLB for the first derivative of the Gaussian pulse

clear all; close all;

pulseWidth = 1e-9;  % <==== Change this for other pulse-widths

Ta = 100e-9;  % TOA uncertainty interval, [0,Ta]
zeta = pulseWidth/2.5; % pulse width parameter
res = 1e-12;  % resolution
% Pulse and its derivative
[pulse, pulseDer] = pulses(1, zeta, 1, res);

SNRs = -10:30;
len2 = length(SNRs);
No = 1;
ZZB = zeros(1,len2);
CRB = zeros(1,len2);

% Calculations for ZZLB
z = 0:res:Ta ; 
len = length(z);
corVals = zeros(1,len);
for i=1:length(z);    
    delay = round(z(i)/res);
    corVals(i) = autoCorr(pulse, delay, res);
end

for j=1:len2
    Ep = 10^(0.1*SNRs(j));
    tmp = abs((Ep/No)*(1-corVals));
    Pmins = Q_fn(sqrt(tmp));
    ZZB(j) = (1/Ta) * res * sum(z.*(Ta-z).*Pmins) ; 
    CRB(j) = 1 / (2*(Ep/No)*pulseCorr(pulseDer, pulseDer, 0, 0, res)) ;
end

figure; semilogy(SNRs,sqrt(ZZB)*1e9,'-',SNRs,sqrt(CRB)*1e9,'--'); 
xlabel('SNR (dB)'); ylabel('RMSE (ns)'); grid on;
