% Copyright �2008 
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

% Chapter-5 Problem-7

% Returns the identification rate for a certain channel model 

clear all; close all;

'CM1 and CM2'
cmNo     = 1;
med_ind1 = 0:80;        % Indices of maximum excess delays for CM-1
med_ind2 = 0:80;        % Indices of maximum excess delays for CM-2

% CM(x)
load(['CM' num2str(cmNo) '_1000_imr_new'])
t           = 0:ts:((size(h_all,1)-1)*ts);

% Obtain MED PDFs for CM(x) and CM(x+1)
MED_param1 = [2.6685 0.4837];                   % Parameters obtained from Table 3.5
MED_pdf1   = lognpdf(med_ind1,MED_param1(1),MED_param1(2));
MED_param2 = [3.3003 0.3843];                   % Parameters obtained from Table 3.5
MED_pdf2   = lognpdf(med_ind2,MED_param2(1),MED_param2(2));

% Calculate identification rate
med_rate1       = 0;
for jj = 1:1000
    
    % Calculate the relevant statistics for current channel realization
    t_m1    = calc_mean_excess_delay_spread (h_all(:,jj),t);    % Calculate the maximum excess delay of current channel realization
    med_all1(jj) = t_m1; 
       
    % MED Identification Rate
    if MED_pdf1(ceil(t_m1))/MED_pdf2(ceil(t_m1))>1
        med_rate1 = med_rate1+1;
    end

    if mod(jj,100)==0; jj, end
end

% Probability of correct identification of CM-1 using maximum excess delay,
% and using 100 channel realizations
med_rate1       = med_rate1 / 1000 



