% Copyright �2008 
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

% Chapter-3 Problem-6

tau0  = 0   ;  % ns. 
tau1  = 1.2 ;  % ns. 
tau2  = 1.7 ;  % ns.
tau3  = 3.2 ;  % ns.
tau4  = 5.1 ;  % ns.
c1    = 1   ; 
c2    = 5   ;  % ns

taus   = [tau0 tau1 tau2 tau3 tau4] ; % Delay vector
Omegas = c1 * exp(-taus/c2);          % Energy parameters of Nakagami random variables
m      = 1.5 ;                        % Nakagami m-factor

% -------------------------- Part (a) -------------------------------
num   = 1e4 ;  % number of realizations
chans = zeros(5, num) ;

for i=1:5
    % Generate Nakagami-m with energy Omega
    chans(i,:) = sqrt (gamrnd(m,Omegas(i),1,num) / m ) ;
end
% -------------------------- Part (b) -------------------------------
[maxVals, maxInds] = max(chans);
probFirstStrongest = sum(maxInds==1) / num 

% -------------------------- Part (c) -------------------------------
probSecondStrongest = sum(maxInds==2) / num 
probThirdStrongest  = sum(maxInds==3) / num 
probFourthStrongest = sum(maxInds==4) / num 
probFifthStrongest  = sum(maxInds==5) / num 

MSE = 0;
for i=1:num
    MSE = MSE + taus(maxInds(i))^2 ;
end
MSE = MSE / num







