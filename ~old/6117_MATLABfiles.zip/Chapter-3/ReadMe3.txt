Problem Solution:

chap3prob6.m	: A MATLAB script for the solution of Problem 6 in Chapter 3