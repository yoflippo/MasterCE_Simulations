
Effective bandwidth:

effBW.m     : Calculates the effective bandwidth of the Gaussian doublet (i.e., the second derivative of the Gaussian pulse)


CRLB versus SNR:

CRLBvsSNR.m : A MATLAB script that plots the CRLBs on the unbiased TOA estimators for the Gaussian doublet



Problem Solution:

chap4prob8.m	  : A MATLAB script for the solution of Problem 8 in Chapter 4