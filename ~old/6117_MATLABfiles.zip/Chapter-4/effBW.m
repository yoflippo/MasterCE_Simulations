% Copyright �2008 
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

% Calculates the effective bandwidth of the second derivative of 
% the Gaussian pulse
function [beta] = effBW (zeta)
% zeta  : Pulse parameter in seconds

% Example:
% >> beta = effBW (3e-9)

res = 1e-12 ;  % resolution
t = (-3*zeta):res:(3*zeta) ;

% Second derivative of the Gaussian pulse and its derivative
pulse = exp(-2*pi*t.^2/zeta^2) .* (1-4*pi*t.^2/zeta^2) ;
pulseDer = exp(-2*pi*t.^2/zeta^2) .* (16*pi^2*t.^3/zeta^4-12*pi*t/zeta^2) ;

% Pulse energies
E1 = res * sum(pulse.^2); 
E2 = res * sum(pulseDer.^2);

% Effective bandwidth
beta = sqrt( (E2/(4*pi^2)) / E1 ) ;



