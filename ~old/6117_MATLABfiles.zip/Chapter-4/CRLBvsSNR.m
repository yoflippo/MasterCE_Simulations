% Copyright �2008 
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

% Plots the CRLBs on the unbiased TOA estimators for the second 
% derivative of the Gaussian pulse

zeta = 0.1e-9;
beta = effBW (zeta);
SNRs = -10:0.01:10;    % in dB
SNRs2 = 10.^(0.1*SNRs);
CRLBs = 1./(2*sqrt(2)*pi*beta*sqrt(SNRs2));
plot(SNRs,CRLBs/1e-12,'-');
xlabel('SNR (dB)'); ylabel('CRLB (ps)'); grid on;