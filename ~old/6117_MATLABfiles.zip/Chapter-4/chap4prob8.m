% Copyright �2008 
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

% Chapter-4 Problem-8

clear all; close all;

% Positions of the reference nodes (in meters)
Ref1    = [ 10  10] ;
Ref2    = [-10  10] ;
Ref3    = [-10 -10] ;
Ref4    = [ 10 -10] ;
Ref_All = [ Ref1 ; Ref2 ; Ref3 ; Ref4 ] ;

% -------------------------- Part (a) -------------------------------
% Target Positions
target = 2 * rand(500,2) - 1 ;

% -------------------------- Part (b) -------------------------------
SNR_dB  = 5; % in dB scale 
SNR     = 10^(SNR_dB/10); % in linear scale 
beta    = 5e9; % effective bandwidth (GHz)
c       = 3e8; % speed of light (m/s)
N_L     = 4; % number of reference nodes
Psi_all = zeros(500,4); % angles between target and reference nodes
% Calculate the angles with each of the BSs for each measurement
for jj = 1:4
    Psi_all(:,jj) = atan2(target(:,2)-Ref_All(jj,2),target(:,1)-Ref_All(jj,1));
end

k = zeros(500,1); % The double-summation terms in the denominator of (4.62)
for ii = 1:N_L
    for jj = 1:(ii-1)
        k = k + sin(Psi_all(:,ii)-Psi_all(:,jj)).^2;
    end
end

MMSE = c^2 * N_L ./ (8*pi^2*beta^2*SNR*k) ;

[minMMSE posInd] = min(MMSE);
minPos = target(posInd,:)
[maxMMSE posInd] = max(MMSE);
maxPos = target(posInd,:)
MMSE_mean = mean(MMSE)


% -------------------------- Part (c) -------------------------------
% MMSE is minimum at the origin.


% -------------------------- Part (d) -------------------------------
SNR_dB  = 0:0.5:15;
SNR     = 10.^(SNR_dB/10);
MMSE2   = zeros(1,length(SNR));
% Obtain the MMSEs
for jj = 1:length(SNR)
    MMSE2(jj)   = mean(c^2 * N_L ./ (8*pi^2*beta^2*SNR(jj)*k));
end
% Plot the results
figure, plot(SNR_dB,MMSE2), xlabel('SNR (dB)'), ylabel('MMSE (m^2)'), grid on

% -------------------------- Part (e) -------------------------------
SNR_dB  = 5;
SNR     = 10^(SNR_dB/10);
beta    = (3.5:0.25:7)*10^9;
MMSE3   = zeros(1,length(beta));
% Obtain the MMSEs
for jj = 1:length(beta)
    MMSE3(jj)   = mean(c^2 * N_L ./ (8*pi^2*beta(jj)^2*SNR*k));
end
% Plot the results
figure, plot(beta,MMSE3), xlabel('\beta (GHz)'), ylabel('MMSE (m^2)'), grid on
