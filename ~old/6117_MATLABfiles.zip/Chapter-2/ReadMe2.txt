
UWB Pulse Generation:

GausDoublet.m     : Generates Gaussian doublets.

modifiedHermite.m : Generates UWB pulses based on modified Hermite polynomials

Gaus5thDer.m	  : Generates the 5th derivative of the Gaussian pulse



Problem Solution:

chap2prob4.m	  : A MATLAB script for the solution of Problem 4 in Chapter 2

