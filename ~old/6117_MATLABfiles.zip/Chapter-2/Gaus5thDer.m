% Copyright �2008
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

function [pulse] = Gaus5thDer (t, A, sigma)
% Generates the 5th derivative of the Gaussian pulse
% Please refer to eqn (2.16) 

% t          : Time instants to evaluate the pulse
% sigma      : A parameter that controls the pulse width
% pulse      : 5th derivative of the Gaussian pulse

% Example:
% >> t=-0.25e-9:1e-12:0.25e-9;
% >> sigma = 0.5e-10;
% >> A = 1e-62;
% >> pulse = Gaus5thDer (t, A, sigma);

% Resolution
res = t(2)-t(1);

% Gaussian doublet (please refer to (2.5))
pulse = A * exp(-t.^2/(2*sigma^2)) .* (-t.^5/sigma^4+10*t.^3/sigma^2-15*t) / (sqrt(2*pi)*sigma^7) ;

% Plot the pulse
figure(3); plot(t/1e-9, pulse); % t in nanoseconds
grid on; xlabel('Time (ns)'); ylabel('Amplitude');

