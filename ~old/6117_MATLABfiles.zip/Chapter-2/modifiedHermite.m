% Copyright �2008
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

function [h3, h4, h5] = modifiedHermite (t, sigma)
% Generates normalized UWB pulses based on 3rd, 4th and 5th order 
% modified Hermite polynomials (MHPs)
% Please refer to Fig. 2.4

% t          : Time instants to evaluate the pulses
% sigma      : A parameter that controls the pulse-width
% h3         : Pulse based on 3rd order MHP
% h4         : Pulse based on 3rd order MHP
% h5         : Pulse based on 3rd order MHP

% Example:
% >> t=-0.5e-9:1e-11:0.5e-9;
% >> sigma = 6e-11;
% >> [h3, h4, h5] = modifiedHermite (t, sigma);

% MHP of order 3
h3 = exp(-t.^2/(4*sigma^2)) .* ( t.^3/sigma^2 - 3*t ) / sigma^4 ;
% MHP of order 4
h4 = exp(-t.^2/(4*sigma^2)) .* ( t.^4/sigma^4 - 6*t.^2/sigma^2 + 3 ) / sigma^4 ;
% MHP of order 5
h5 = exp(-t.^2/(4*sigma^2)) .* ( t.^5/sigma^4 - 10*t.^3/sigma^2 + 15*t ) / sigma^6 ;

% Normalize
Delta = t(2)-t(1);
h3 = h3 / sqrt(sum(h3.^2)*Delta);
h4 = h4 / sqrt(sum(h4.^2)*Delta);
h5 = h5 / sqrt(sum(h5.^2)*Delta);

% Plot the pulses
t = t/1e-9 ;  % t in ns.
figure(2); plot(t,h3,'-x',t,h4,'-',t,h5,'--');
legend('MHP of 3rd order','MHP of 4th order','MHP of 5th order',4);
xlabel('Time (ns)'); ylabel('Amplitude');
