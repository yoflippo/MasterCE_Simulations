% Copyright �2008 
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

function [gausPul] = GausDoublet (t, pulseWidth)
% Generates a unit energy Gaussian doublet 
% i.e., the second derivative of a Gaussian pulse 
% Please refer to eqn (2.5) and Fig. 2.3

% t          : Time instants to evaluate the Gaussian doublet
% pulseWidth : Approximate pulse width
% gausPul    : Gaussian doublet

% Example:
% >> t=-1e-9:1e-11:1e-9;
% >> pulseWidth = 1e-9;
% >> gausPulse = GausDoublet (t, pulseWidth);

% Pulse width is around 2.5*tau 
zeta = pulseWidth/2.5 ;  % please refer to (2.5)

% Resolution
res = t(2)-t(1);

% Gaussian monocycle (please refer to (2.5))
gausPul = exp(-2*pi*t.^2/zeta^2) .* (1-4*pi*t.^2/zeta^2) ;
% Normalization
E = res * sum(gausPul.^2);  
gausPul = gausPul/sqrt(E);

% Plot the pulse
figure(1); plot(t/1e-9, gausPul); % t in nanoseconds
grid on; xlabel('Time (ns)'); ylabel('Amplitude');

