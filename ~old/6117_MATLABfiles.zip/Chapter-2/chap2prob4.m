% Copyright �2008 
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

% Chapter-2 Problem-4

% -------------------------- Part (a) -------------------------------
t = -0.25e-9:1e-12:0.25e-9; % time instants
res = t(2)-t(1); % resolutions
A = 1; % first assume A=1, then normalize the energys
sigmas = [1e-11 5e-11 1e-10];
pulse1 = Gaus5thDer (t, A, sigmas(1));
pulse1 = pulse1./sqrt(res*sum(pulse1.^2)); % normalization
pulse2 = Gaus5thDer (t, A, sigmas(2));
pulse2 = pulse2./sqrt(res*sum(pulse2.^2)); % normalization
pulse3 = Gaus5thDer (t, A, sigmas(3));
pulse3 = pulse3./sqrt(res*sum(pulse3.^2)); % normalization
% Plot the pulses
figure(4); plot(t/1e-9,pulse1,'-.',t/1e-9,pulse2,'-',t/1e-9,pulse3,':');
grid on; xlabel('Time (ns)'); ylabel('Amplitude');
legend('\sigma=1e-11','\sigma=0.5e-10','\sigma=1e-10');

% -------------------------- Part (b) -------------------------------
res_f = 1e6; % Resolution of the Fourier transform curves
f_init = 0.7e9; % Initial frequency 
f_fin = 50e9; % Final frequency
f = f_init:res_f:f_fin;

% Fourier transforms
sigma = 1e-11;
FT1 = 32*pi^5*f.^5 .* exp(-2*pi^2*sigma^2*f.^2) ;
FT1 = FT1/sqrt(res_f*sum(FT1.^2)); % normalization
sigma = 5e-11;
FT2 = 32*pi^5*f.^5 .* exp(-2*pi^2*sigma^2*f.^2) ;
FT2 = FT2/sqrt(res_f*sum(FT2.^2)); % normalization
sigma = 1e-10;
FT3 = 32*pi^5*f.^5 .* exp(-2*pi^2*sigma^2*f.^2) ;
FT3 = FT3/sqrt(res_f*sum(FT3.^2)); % normalization

figure(5);plot(f/1e9,FT1,'-',f/1e9,FT2,':',f/1e9,FT3,'-.');
xlabel('f (GHz)'); ylabel('Magnitude Spectrum'); grid on;
legend('\sigma=1e-11','\sigma=0.5e-10','\sigma=1e-10');

% -------------------------- Part (c) -------------------------------
k=1e-7;          % Scaling constant given in the question
res_f = 1e5;     % Resolution of the spectral curves
f_init = 0.7e9;  % Initial frequency 
f_fin = 15e9;    % Final frequency
f = f_init:res_f:f_fin;

% Average PSD of the signal
sigma = 5.1e-11;
f_max = sqrt(5)/(2*pi*sigma)
A = sqrt(10^(-13.13)/k)*sigma^5 / (25*sqrt(5)*exp(-2.5)) 
FT = 32*pi^5*A*f.^5 .* exp(-2*pi^2*sigma^2*f.^2) ;
PSD = 10*log10(k*abs(FT).^2) + 30 + 60 ;  % dBm per MHz

% FCC mask for UWB indoor communications systems
res_fm = 1e-2;
f1 = 0.7:res_fm:0.96;
f2 = 0.96:res_fm:1.61;
f3 = 1.61:res_fm:1.99;
f4 = 1.99:res_fm:3.1;
f5 = 3.1:res_fm:10.6;
f6 = 10.6:res_fm:15;
FCCmask = [-41.3*ones(1,length(f1)) -75.3*ones(1,length(f2)) -53.3*ones(1,length(f3)) ...
           -51.3*ones(1,length(f4)) -41.3*ones(1,length(f5)) -51.3*ones(1,length(f6))] ;

% Plot the results
figure(6); plot([f1 f2 f3 f4 f5 f6], FCCmask, '-r');
hold on; plot(f/1e9,PSD);  % PSD vs f (GHz)
xlabel('f (GHz)'); ylabel('PSD (dBm/MHz)'); grid on;
legend('FCC Mask','5th Derivative of Gaussian Pulse',4)
axis([0.7 15 -100 -40]);
hold off;
