% Copyright �2008 
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

% Link Budget Analysis (please refer to Example 8.3 and 
% Exercise 3 of Chapter-8

function [SNRs] = linkBudgetAnalysis(CM, d, T)
% CM: Channel model (CM-1,...,CM-4)
% CM = 1; % 1,2,3,4
% d : Set of distances in meters
% T : Length of symbol interval in seconds

% System parameters
L_imp = 7; % Implementation loss in dB
NF = 3; % Receiver noise figure in dB
f_c = 5e9; % Center frequency in Hz
B = 2e9; % Bandwidth in Hz
f_L = f_c-B/2; % lower frequency
f_H = f_c+B/2; % upper frequency

P_tx_amp = 10^(-4.13)*1e-3*1e-6; % Watt/Hz

N0 = 10^(-17.4)*1e-3; % Noise spectral density in Watt/Hz
d0 = 1; % meter

% CM-1
if CM==1
    PL0_dB = -43.9;
    kappa = 1.12;
    n = 1.79;
end
% CM-2
if CM==2
    PL0_dB = -48.7;
    kappa = 1.53;
    n = 4.58;
end
% CM-3
if CM==3
    PL0_dB = -35.4;
    kappa = 0.03;
    n = 1.63;
end
% CM-4
if CM==4
    PL0_dB = -59.9;
    kappa = 0.71;
    n = 3.07;
end

PL0 = 10^(0.1*PL0_dB);

% Formula from Chapter 8 Section 2
SNRs = PL0 * P_tx_amp * T * (f_L^(-2*kappa-1)-f_H^(-2*kappa-1)) ...
       ./ ( (2*kappa+1)*N0*f_c^(-2*(kappa+1))*(d/d0).^n ) ;
   
SNRs = 10*log10(SNRs) - L_imp - NF;       
       
%figure(1); plot(d, 10*log10(SNRs)); grid on;
%xlabel('Distance (m.)'); ylabel('SNR (dB)');



