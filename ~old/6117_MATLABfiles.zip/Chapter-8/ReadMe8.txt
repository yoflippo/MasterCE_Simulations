
Link Budget Analysis: 

linkBudgetAnalysis.m : Calculates the SNRs based on link budget analysis (please refer to Example 8.3 and Problem 3 of Chapter-8)


Problem Solution:

chap8prob3.m	  : A MATLAB script for the solution of Problem 3 in Chapter 8