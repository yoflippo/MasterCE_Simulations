% Copyright �2008 
% Zafer Sahinoglu, Sinan Gezici, Ismail Guvenc

% Chapter-8 Problem-3 (also see Example 8.3)

d = 1:0.01:25; % meters
Ts = 1e-6; % seconds

CM=1;
SNRs1 = linkBudgetAnalysis(CM, d, Ts);
CM=2;
SNRs2 = linkBudgetAnalysis(CM, d, Ts);
CM=3;
SNRs3 = linkBudgetAnalysis(CM, d, Ts);
CM=4;
SNRs4 = linkBudgetAnalysis(CM, d, Ts);

figure(1); plot(d,SNRs1,'-',d,SNRs2,'--',d,SNRs3,'-.',d,SNRs4,':');
grid on; xlabel('Distance (m.)'); ylabel('SNR (dB)');
legend('CM-1','CM-2','CM-3','CM-4',3);

%-------------------------------------------------------
CM=1;

Ts = 1e-6;
SNRs1 = linkBudgetAnalysis(CM, d, Ts);
Ts = 4e-6;
SNRs2 = linkBudgetAnalysis(CM, d, Ts);
Ts = 10e-6;
SNRs3 = linkBudgetAnalysis(CM, d, Ts);
Ts = 100e-6;
SNRs4 = linkBudgetAnalysis(CM, d, Ts);

figure(2); plot(d,SNRs1,'-',d,SNRs2,'--',d,SNRs3,'-.',d,SNRs4,':');
grid on; xlabel('Distance (m.)'); ylabel('SNR (dB)');
legend('T_s=1 \mus','T_s=4 \mus','T_s=10 \mus','T_s=100 \mus');

%-------------------------------------------------------
CM=2;

Ts = 1e-6;
SNRs1 = linkBudgetAnalysis(CM, d, Ts);
Ts = 4e-6;
SNRs2 = linkBudgetAnalysis(CM, d, Ts);
Ts = 10e-6;
SNRs3 = linkBudgetAnalysis(CM, d, Ts);
Ts = 100e-6;
SNRs4 = linkBudgetAnalysis(CM, d, Ts);

figure(3); 
plot(d,SNRs1,'-',d,SNRs2,'--',d,SNRs3,'-.',d,SNRs4,':');
grid on; xlabel('Distance (m.)'); ylabel('SNR (dB)');
legend('T_s=1 \mus','T_s=4 \mus','T_s=10 \mus','T_s=100 \mus');
