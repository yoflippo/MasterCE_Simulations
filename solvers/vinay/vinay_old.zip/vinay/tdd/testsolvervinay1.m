close all;
clearvars;
clc;

TestSolverVinay(@execute_vinay1,'Vinay');
